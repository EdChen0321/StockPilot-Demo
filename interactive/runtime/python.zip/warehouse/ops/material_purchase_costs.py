"""Purchase amounts in cents; quantities in thousandths of the base unit."""
import re
from datetime import date
from .stock import optional_money

MAX_CENTS = 9007199254740991


def bounded(value):
    if value > MAX_CENTS:
        raise ValueError('物料採購金額超過可處理上限，請拆單')
    return value


def subtotal(quantity, price):
    # Round each line half-up to one cent, including fractional base units.
    return None if price is None else bounded((quantity * price + 500) // 1000)


def metadata(body):
    expected, comment = body.get('expected_date', ''), body.get('comment', '')
    if not isinstance(expected, str) or (expected and not re.fullmatch(r'\d{4}-\d{2}-\d{2}', expected)):
        raise ValueError('預計到貨日須為 YYYY-MM-DD 或空白')
    if expected:
        try:
            date.fromisoformat(expected)
        except ValueError:
            raise ValueError('預計到貨日無效') from None
    if not isinstance(comment, str) or len(comment) > 2000:
        raise ValueError('備註須為最多2000字的文字')
    return expected, comment.strip()


def receipt_costs(lines, supplied, body):
    by_id = {item['material_id']: item for item in supplied}
    if len(by_id) != len(supplied) or set(by_id) != {line['material_id'] for line in lines}:
        raise ValueError('費用品項須與本批物料完全一致且不可重複')
    result = []
    for line in lines:
        item = by_id[line['material_id']]
        if 'unit' in item and item['unit'] != line['unit']:
            raise ValueError('費用單位須與本批物料基礎單位一致')
        price = optional_money(item.get('unit_price'))
        result.append(dict(line, unit_price_cents=price, subtotal_cents=subtotal(line['quantity'], price)))
    freight, tax = optional_money(body.get('freight')), optional_money(body.get('tax'))
    total = None
    if freight is not None and tax is not None and all(l['subtotal_cents'] is not None for l in result):
        total = bounded(sum(l['subtotal_cents'] for l in result) + freight + tax)
    return result, freight, tax, total
