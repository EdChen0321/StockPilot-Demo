"""Three local demo surfaces backed by one isolated order and stock database."""
import argparse
import importlib
import importlib.util
import json
import re
from html import escape
import threading
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from urllib.parse import parse_qs, quote

from ops.catalogue import Catalogue, product as catalogue_product
from ops.locations import Locations
from ops.orders import Orders
from ops.sales import sales
from ops.server import Handler, HttpError, create_server
from ops.stock import Stock
from ops.store import ConflictError, Store
from .order_queries import order_page
from .order_returns import order_returns
from .pickup import Pickup, counts as pickup_counts
from .dashboard import report as dashboard_report
from .kol_queries import report as portfolio_kol_report


def extend_catalogue(store, demo, kol_store, kol_catalogue, kol_demo):
    """Load explicitly installed showcase products; never seed stock on startup."""
    with store.connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS portfolio_products(sku TEXT PRIMARY KEY, data TEXT NOT NULL)')
        extra = [json.loads(row[0]) for row in db.execute('SELECT data FROM portfolio_products ORDER BY rowid')]
    mapping = {row['sku']: row['id'] for row in kol_catalogue.Catalogue(kol_store).list()['products']}
    for item in extra:
        if item['sku'] not in mapping:
            product = kol_catalogue.Catalogue(kol_store).create(dict(
                operation_id=operation('showcase-mirror/' + item['sku']), name=item['name'],
                sku=item['sku'], barcode=item['sku'], kind='product', attributes={}))
            mapping[item['sku']] = product['id']
        kol_demo['products'][item['sku']] = mapping[item['sku']]
        demo['products'].append(item)
    return demo


ROOT = Path(__file__).resolve().parents[1]
OPERATIONS_ROOT = ROOT.parent / '營運系統'
ITEMS = (
    ('多節硬式泳餌', '仿魚輪廓與分節結構，適合放慢收線與停頓操作。', 'TIDE-SWIMBAIT', '1480.00', 8),
    ('浮水青蛙餌', '蛙形輪廓與草綠配色，適合探索草邊與水面。', 'TIDE-FROG', '245.00', 6),
    ('4 吋棒蟲軟餌', '柔軟直尾造型，一包五入，適合細緻操作。', 'TIDE-WORM', '202.00', 5),
)


def operation(name):
    return 'portfolio/' + name


def seed_warehouse(store):
    """Seed only the dedicated demo database, using existing business commands."""
    catalogue, stock, locations = Catalogue(store), Stock(store), Locations(store)
    with store.connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS portfolio_meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)')
        row = db.execute("SELECT value FROM portfolio_meta WHERE key='seed'").fetchone()
        if row:
            return json.loads(row['value'])
        if db.execute('SELECT 1 FROM current_orders LIMIT 1').fetchone():
            raise RuntimeError('Portfolio database is not empty and has no demo marker; choose a new database path')
    account = catalogue.account(dict(operation_id=operation('account'), name='Portfolio storefront', platform='manual'))
    place = locations.save(dict(operation_id=operation('place'), address='TIDE', position='A-01',
                                name='Pick shelf', can_import=True, can_export=True, can_return=True,
                                entry_state='import', comment='Opening stock shelf'))
    products = []
    for index, (name, description, sku, price, quantity) in enumerate(ITEMS):
        product = catalogue.create(dict(operation_id=operation(f'product/{index}'), name=name, sku=sku,
                                        barcode=sku, kind='product', specification=description, attributes={}))
        products.append(dict(id=product['id'], name=name, description=description, sku=sku,
                             price=price, initial_quantity=quantity))
    receipt = stock.receipt(dict(operation_id=operation('receipt'), number='PORTFOLIO-OPENING',
                                 source='Opening stock', freight='0', tax='0',
                                 lines=[dict(product_id=p['id'], quantity=p['initial_quantity'], unit_price='5.00') for p in products]))
    stock.confirm_receipt(receipt['id'], dict(operation_id=operation('receipt-confirm')))
    locations.assign(dict(operation_id=operation('putaway'), receipt_id=receipt['id'], place_id=place['id'],
                          quantity=sum(p['initial_quantity'] for p in products)))
    result = dict(account_id=account['id'], place_id=place['id'], products=products)
    with store.connect() as db:
        db.execute("INSERT OR IGNORE INTO portfolio_meta VALUES('seed',?)", (json.dumps(result),))
    return result


def localize_warehouse(store, demo):
    """Translate only the synthetic catalogue created by this portfolio launcher."""
    catalogue = Catalogue(store)
    for index, entry in enumerate(demo['products']):
        name, description = ITEMS[index][:2]
        with store.connect() as db:
            current = catalogue_product(db, entry['id'])
        if current['name'] != name or current['specification'] != description or current['barcode'] != entry['sku']:
            catalogue.update(entry['id'], dict(operation_id=operation(f'localize-product/{index}'),
                expected_version=current['version'], name=name, specification=description, barcode=entry['sku'],
                reason='本機作品集改為中文示範'))
        entry.update(name=name, description=description)
    return demo


def load_operations():
    """Load the sibling operations package under a distinct name, without sharing its DB."""
    if not (OPERATIONS_ROOT / 'ops' / '__init__.py').is_file():
        raise RuntimeError('The sibling operations project is required for KOL analysis')
    spec = importlib.util.spec_from_file_location('portfolio_operations', OPERATIONS_ROOT / 'ops' / '__init__.py',
                                                  submodule_search_locations=[str(OPERATIONS_ROOT / 'ops')])
    package = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[spec.name] = package
    spec.loader.exec_module(package)
    return (importlib.import_module('portfolio_operations.store'),
            importlib.import_module('portfolio_operations.catalogue'),
            importlib.import_module('portfolio_operations.orders'),
            importlib.import_module('portfolio_operations.kol'),
            importlib.import_module('portfolio_operations.server'))


def seed_kol(store, catalogue_module, orders_module, kol_module):
    """Set up the existing operations engine for synthetic storefront attribution."""
    catalogue = catalogue_module.Catalogue(store)
    kol_module.Kol(store).save(dict(operation_id=operation('kol-creator'), name='Alex Rivera',
                                    platforms='manual', started_at='2025-01-01T00:00:00+00:00',
                                    utms='alex-tide', keep_case=False, comment='Portfolio campaign record',
                                    campaign_name='Example launch'))
    storefront = catalogue.account(dict(operation_id=operation('storefront-account'), name='Portfolio storefront', platform='manual'))
    products = {}
    for index, (name, _, sku, _, _) in enumerate(ITEMS):
        item = catalogue.create(dict(operation_id=operation(f'storefront-product/{index}'), name=name,
                                     sku=sku, kind='product', attributes={}))
        products[sku] = item['id']
    return dict(account_id=storefront['id'], products=products)


def seed_sample_order(store, portfolio):
    """Create one linked, repeatable customer order through the existing order engine."""
    token = '00000000000000000000000000000001'
    item = portfolio['products'][1]
    lines = [dict(product_id=item['id'], quantity=1, unit_price=item['price'])]
    details = dict(customer=dict(name='Morgan Hale', email='morgan@example.invalid', phone=''),
                   delivery=dict(recipient='Morgan Hale', address='Sample pickup point'),
                   utm=dict(source='instagram', medium='alex-tide', campaign='tide-launch'),
                   payment_method='模擬付款', shipping_method='超商取貨')
    with store.connect() as db:
        db.execute('CREATE TABLE IF NOT EXISTS portfolio_checkouts(token TEXT PRIMARY KEY, cart TEXT NOT NULL, ordered_at TEXT NOT NULL)')
        db.execute('INSERT OR IGNORE INTO portfolio_checkouts VALUES(?,?,?)',
                   (token, json.dumps(lines, sort_keys=True), '2026-11-01T09:00:00+08:00'))
        db.execute('INSERT OR IGNORE INTO portfolio_checkout_details(token,details) VALUES(?,?)',
                   (token, json.dumps(details, ensure_ascii=False, sort_keys=True)))
    Orders(store).receive(dict(operation_id=operation('sample-order'), account_id=portfolio['account_id'],
        order_id='TIDE-' + token.upper(), ordered_at='2026-11-01T09:00:00+08:00',
        customer_ref='TIDE-CUST-00000001', utm_medium='alex-tide', lines=lines))


def mirror_operations_order(server, order_id, ordered_at, lines, details):
    """Send one demo order to the existing operations/KOL engine, idempotently."""
    account = server.kol_portfolio['account_id']
    with server.kol_store.connect() as db:
        if db.execute('SELECT 1 FROM current_orders WHERE account_id=? AND order_id=?',
                      (account, order_id)).fetchone():
            return
    known = {p['id']: p for p in server.portfolio['products']}
    mapped = [dict(product_id=server.kol_portfolio['products'][known[line['product_id']]['sku']],
                   quantity=line['quantity'], unit_price=line['unit_price']) for line in lines]
    server.kol_orders.Orders(server.kol_store).receive(dict(
        operation_id=operation('storefront-order/' + order_id), account_id=account,
        order_id=order_id, ordered_at=ordered_at,
        customer_ref=details.get('customer', {}).get('reference') or 'TIDE-CUST-' + order_id[5:13],
        utm_medium=details.get('utm', {}).get('medium', ''),
        order_total=f"{sum(Decimal(line['unit_price']) * line['quantity'] for line in lines):.2f}",
        lines=mapped))


def sync_existing_orders(server):
    """Recover demo orders created before the operations mirror existed or after a failed mirror."""
    with server.kol_store.connect() as db:
        mirrored = {row[0] for row in db.execute('SELECT order_id FROM current_orders WHERE account_id=?',
                                               (server.kol_portfolio['account_id'],))}
    with server.store.connect() as db:
        rows = db.execute('''SELECT c.order_id, v.normalized, d.details FROM current_orders c
            JOIN order_versions v USING(account_id,order_id,revision)
            LEFT JOIN portfolio_checkout_details d ON d.token=lower(substr(c.order_id,6))
            WHERE c.account_id=? AND c.order_id LIKE 'TIDE-%' ''',
            (server.portfolio['account_id'],)).fetchall()
    for row in rows:
        if row['order_id'] in mirrored:
            continue
        order = json.loads(row['normalized'])
        lines = [dict(product_id=line['product_id'], quantity=line['quantity'],
                      unit_price=f"{line['amount_cents'] // line['quantity'] // 100}.{line['amount_cents'] // line['quantity'] % 100:02d}")
                 for line in order['lines']]
        mirror_operations_order(server, row['order_id'], order['ordered_at'], lines,
                                json.loads(row['details']) if row['details'] else {})


def fulfillment_state(order, shipments):
    """Derive customer status from every linked shipment, including split dispatches."""
    if order.get('status') == 'cancelled':
        return 'cancelled'
    required = {line['product_id']: line['quantity'] for line in order['lines']}
    shipped = {product_id: 0 for product_id in required}
    for shipment in shipments:
        if shipment['state'] == 'shipped':
            for line in shipment['lines']:
                if line['product_id'] in shipped:
                    shipped[line['product_id']] += line['quantity']
    if required and all(shipped[product_id] >= quantity for product_id, quantity in required.items()):
        return 'shipped'
    if any(shipped.values()):
        return 'partially_shipped'
    active = {shipment['state'] for shipment in shipments if shipment['state'] != 'cancelled'}
    for state in ('staged', 'picked', 'allocated', 'draft'):
        if state in active:
            return state
    return 'placed'


def admin_shell(role, active, fulfillment_url, shop_url, sales_url, operations_url):
    warehouse = fulfillment_url + 'warehouse-workspace#'
    operations = operations_url + '#'
    if role == 'sales':
        primary = (
            ('總覽', sales_url, 'hub'),
            ('顧客訂單', sales_url + 'orders', 'customer-orders'),
            ('取貨追蹤', sales_url + 'pickups', 'pickups'),
            ('銷售報表', sales_url + 'sales', 'sales'),
            ('KOL 分析', sales_url + 'kol', 'kol'),
        )
        work = (
            ('匯入訂單', operations + 'import', 'import'),
            ('手動接單', operations + 'orders', 'orders'),
            ('訂單來源', operations + 'sources', 'sources'),
            ('匯入紀錄', operations + 'history', 'history'),
            ('SKU 商品對照', operations + 'catalogue', 'catalogue'),
        )
        more = (
            ('銷售明細查詢', operations + 'sales', 'sales-detail'),
            ('進階銷售總覽', operations + 'dashboard', 'dashboard'),
            ('KOL 設定', operations + 'kol', 'kol-settings'),
            ('AI 助理', operations + 'assistant', 'assistant'),
            ('AI 設定', operations + 'ai-settings', 'ai-settings'),
            ('AI 評測', operations + 'ai-evaluation', 'ai-evaluation'),
        )
        title = '營運後台'
    else:
        primary = (
            ('出貨交接', fulfillment_url + 'fulfillment', 'operations'),
            ('出貨管理', warehouse + 'shipping', 'shipping'),
            ('可用庫存', warehouse + 'inventory', 'inventory'),
            ('SKU 商品庫', warehouse + 'catalogue', 'catalogue'),
            ('進貨入庫', warehouse + 'stock', 'stock'),
            ('櫃位管理', warehouse + 'locations', 'locations'),
        )
        work = (
            ('調撥管理', warehouse + 'transfers', 'transfers'),
            ('商品採購／叫貨', warehouse + 'goods-purchases', 'goods-purchases'),
            ('物料與採購', warehouse + 'materials', 'materials'),
            ('出貨報表', warehouse + 'shipping-statistics', 'shipping-statistics'),
        )
        more = (
            ('庫存詳細', warehouse + 'quality', 'quality'),
            ('庫存與出貨數據', warehouse + 'stock-reports', 'stock-reports'),
            ('AI 助理', warehouse + 'assistant', 'assistant'),
            ('AI 設定', warehouse + 'ai-settings', 'ai-settings'),
            ('AI 評測', warehouse + 'ai-evaluation', 'ai-evaluation'),
        )
        title = '出貨後台'

    def links(items):
        output = []
        for label, url, key in items:
            current = ' aria-current="page"' if key == active else ''
            output.append(f'<a href="{escape(url, quote=True)}" data-nav-key="{key}"{current}>{escape(label)}</a>')
        return ''.join(output)

    sales_current = ' aria-current="page"' if role == 'sales' else ''
    fulfillment_current = ' aria-current="page"' if role == 'fulfillment' else ''

    return (f'<header class="hub-topbar"><button id="hub-menu" type="button" aria-label="開啟功能選單" '
            f'aria-controls="hub-sidebar" aria-expanded="false">☰</button>'
            f'<a class="hub-topbrand" href="{sales_url}">StockPilot <span>／ {title}</span></a>'
            f'<nav class="admin-switch" aria-label="切換工作區">'
            f'<a href="{shop_url}">前台</a>'
            f'<a href="{sales_url}"{sales_current}>營運</a>'
            f'<a href="{fulfillment_url}fulfillment"{fulfillment_current}>出貨</a>'
            f'</nav></header>'
            f'<aside id="hub-sidebar" class="hub-sidebar" aria-label="{title}功能">'
            f'<a class="hub-sidebar-brand" href="{sales_url}" aria-label="StockPilot 營運總覽">S<span>.</span><small>STOCKPILOT</small></a>'
            f'<p>{title}</p><p class="admin-demo">本機展示 · 虛構資料<br>非真實商業成果</p><nav class="admin-nav" aria-label="主要功能">{links(primary)}</nav>'
            f'<p>資料作業</p><nav class="admin-nav" aria-label="資料作業">{links(work)}</nav>'
            f'<details class="admin-more"><summary>更多功能</summary><nav class="admin-nav" aria-label="更多功能">{links(more)}</nav></details>'
            f'</aside><button id="hub-overlay" class="hub-overlay" type="button" aria-label="關閉功能選單"></button>')


def workspace_page(root, role, fulfillment_url, shop_url, sales_url, operations_url):
    html = (root / 'web' / 'index.html').read_text(encoding='utf-8')
    title = 'StockPilot 營運後台' if role == 'sales' else 'StockPilot 出貨後台'
    html = html.replace('<title>營運工作台</title>', f'<title>{title}</title>', 1)
    shell = admin_shell(role, '', fulfillment_url, shop_url, sales_url, operations_url)
    html = html.replace('</head>', '<link rel="stylesheet" href="/admin-shell.css">'
                        '<link rel="stylesheet" href="/admin-workspace.css">'
                        '<link rel="stylesheet" href="/theme-a.css">'
                        '<script src="/admin-shell.js" defer></script></head>', 1)
    html = html.replace('<body>', f'<body data-role="{role}" data-admin-workspace="true">{shell}', 1)
    return html.encode('utf-8')


def role_page(role, path, fulfillment_url, shop_url, sales_url, operations_url):
    pages = {
        'shop': 'product' if path.startswith('/product/') else 'store',
        'sales': 'pickups' if path == '/pickups' else 'kol' if path == '/kol' else 'sales' if path == '/sales' else 'customer-order-page' if path.startswith('/orders/') else 'customer-orders' if path == '/orders' else 'hub',
        'fulfillment': 'operations',
    }
    active = pages[role]
    html = (ROOT / 'portfolio' / 'index.html').read_text(encoding='utf-8')
    for section in ('hub', 'pickups', 'store', 'product', 'customer-orders', 'customer-order-page', 'sales', 'operations', 'kol'):
        if section != active:
            html = re.sub(rf'<section class="app-section [^\"]* view-panel" id="{section}"[\s\S]*?</section>\s*', '', html, count=1)
    html = re.sub(rf'(<section class="app-section [^\"]* view-panel" id="{active}"[^>]*?) hidden>', r'\1>', html, count=1)
    navigation = {
        'shop': '<a href="/shop" data-store-nav="products">全部商品</a><a href="/shop?style=TIDE-SWIMBAIT" data-store-nav="hard">硬餌</a><a href="/shop?style=TIDE-FROG" data-store-nav="surface">水面餌</a><a href="/shop?style=TIDE-WORM" data-store-nav="soft">軟餌</a><a href="/#track-form" data-store-nav="tracking">訂單查詢</a><a href="/cart" id="cart-toggle" data-store-nav="cart" aria-controls="cart-title" aria-expanded="false">購物袋 <span id="header-cart-count">0</span></a>',
        'sales': '',
        'fulfillment': '',
    }[role]
    html = html.replace('<nav aria-label="主要導覽"></nav>', f'<nav aria-label="主要導覽">{navigation}</nav>', 1)
    if role in ('sales', 'fulfillment'):
        shell = admin_shell(role, 'customer-orders' if active == 'customer-order-page' else active, fulfillment_url, shop_url, sales_url, operations_url)
        html = re.sub(r'<header class="site-header">[\s\S]*?</header>', shell, html, count=1)
        html = html.replace('<main>', '<main class="hub-main">', 1)
        html = html.replace('<main id="main-content">', '<main id="main-content" class="hub-main">', 1)
        html = html.replace('</head>', '<link rel="stylesheet" href="/admin-shell.css">'
                            '<script src="/admin-shell.js" defer></script></head>', 1)
        html = html.replace('content="#0b252c"', 'content="#f8faf9"', 1)
        html = re.sub(r'<footer>[\s\S]*?</footer>', '', html, count=1)
    if role == 'sales' and active == 'hub':
        html = html.replace('<script src="/dashboard.js"', '<script src="/vendor/echarts-6.1.0/echarts.min.js" defer></script><script src="/dashboard.js"')
    if role == 'shop':
        html = html.replace('<header class="site-header">', '<a class="skip-link" href="#main-content">Skip to content</a><div class="demo-notice">Demonstration store · No real payments or deliveries</div><header class="site-header">', 1)
        html = html.replace('class="brand-mark">S', 'class="brand-mark">T', 1)
        html = html.replace('class="brand-name">StockPilot', 'class="brand-name">Tide &amp; Tackle', 1)
        html = html.replace('aria-label="StockPilot 首頁"', 'aria-label="Tide &amp; Tackle home"', 1)
    body_attributes = f'data-role="{role}"'
    if role == 'sales':
        body_attributes += f' data-fulfillment-url="{fulfillment_url}"'
    if role == 'shop':
        body_attributes += f' data-page="{active}" data-shop-route="{path.strip("/") or "home"}"'
    html = html.replace('<body>', f'<body {body_attributes}>', 1)
    html = html.replace('StockPilot｜商店與後台', {
        'shop': 'Order confirmation | Tide & Tackle' if path == '/confirmation' else 'Tide & Tackle | Lure Shop',
        'sales': 'StockPilot 營運 HUB｜訂單與銷售',
        'fulfillment': 'StockPilot 出貨後台｜訂單處理',
    }[role], 1)
    html = html.replace('</head>', '<link rel="stylesheet" href="/theme-a.css"></head>', 1)
    return html.encode('utf-8')


class PortfolioHandler(Handler):
    def get(self, path, query):
        role = self.server.role
        if role == 'sales' and path == '/orders' and parse_qs(query).get('order'):
            params = parse_qs(query)
            order_id = params.pop('order')[0]
            retained = '&'.join(f'{quote(key)}={quote(values[0])}' for key, values in params.items()
                                if key in ('q', 'state', 'start', 'end', 'page', 'page_size'))
            self.send_response(302)
            self.send_header('Location', '/orders/' + quote(order_id, safe='') + ('?' + retained if retained else ''))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', '0')
            self.end_headers()
            return
        if role == 'fulfillment' and path == '/':
            order_id = parse_qs(query).get('order', [''])[0]
            target = '/warehouse-workspace#shipping'
            if order_id:
                order = self.order_detail(order_id)
                route = (f"shipping/{order['shipment']['id']}" if order['shipment'] else
                         'shipping/new/' + quote(json.dumps([order['account_id'], order_id], separators=(',', ':')), safe=''))
                target = '/warehouse-workspace#' + route
            self.send_response(302)
            self.send_header('Location', target)
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', '0')
            self.end_headers()
            return
        if path.startswith('/assets/'):
            filename = path.removeprefix('/assets/')
            if filename == 'lake-hero.png':
                return self.send((ROOT / 'portfolio' / 'assets' / filename).read_bytes(), mime='image/png')
            if filename in {'swimbait.webp', 'frog.webp', 'worm.webp',
                            'swimbait-detail.webp', 'frog-detail.webp', 'worm-detail.webp'}:
                return self.send((ROOT / 'portfolio' / 'assets' / filename).read_bytes(), mime='image/webp')
        product_path = path.startswith('/product/') and path.removeprefix('/product/') in {p['sku'] for p in self.server.portfolio['products']}
        if path == '/' or (role == 'sales' and (path in ('/orders', '/sales', '/kol', '/pickups') or path.startswith('/orders/'))) or (role == 'fulfillment' and path in ('/fulfillment', '/demo-fulfillment')) or (role == 'shop' and (path in ('/shop', '/cart', '/checkout', '/confirmation') or product_path)):
            return self.send(role_page(role, path, self.server.fulfillment_url, self.server.shop_url,
                                       self.server.sales_url, self.server.kol_url), mime='text/html; charset=utf-8')
        if path in ('/portfolio.css', '/admin-light.css', '/admin-shell.css', '/admin-workspace.css', '/theme-a.css',
                    '/dashboard.js', '/pickup-ui.js', '/operations-dashboard.css', '/admin-shell.js', '/storefront.css', '/portfolio.js', '/kol-management.js', '/order-detail.js', '/order-detail.css'):
            mime = 'text/css' if path.endswith('.css') else 'text/javascript'
            return self.send((ROOT / 'portfolio' / path.lstrip('/')).read_bytes(), mime=mime + '; charset=utf-8')
        if role == 'fulfillment' and path == '/warehouse-workspace':
            return self.send(workspace_page(ROOT, 'fulfillment', self.server.fulfillment_url,
                                            self.server.shop_url, self.server.sales_url,
                                            self.server.kol_url), mime='text/html; charset=utf-8')
        if role == 'sales' and path.startswith('/vendor/echarts-6.1.0/'):
            filename = path.rsplit('/', 1)[-1]
            if filename in ('echarts.min.js', 'LICENSE', 'NOTICE'):
                return self.send((ROOT / 'web/vendor/echarts-6.1.0' / filename).read_bytes(),
                                 mime='text/javascript' if filename.endswith('.js') else 'text/plain')
        if role == 'sales' and path in ('/api/portfolio/dashboard', '/api/portfolio/pickups'):
            params = parse_qs(query, keep_blank_values=True, max_num_fields=5)
            allowed = ('start', 'end', 'product_id') if path.endswith('dashboard') else ('start', 'end', 'filter', 'order_id')
            if any(k not in allowed or len(v) != 1 for k, v in params.items()):
                raise ValueError('篩選條件不正確')
            values = {k: v[0] for k, v in params.items()}
            if path.endswith('dashboard'):
                return self.send(dashboard_report(self.server, fulfillment_state, **values))
            parcels = self.server.pickup.parcels(**values)
            return self.send(dict(parcels=parcels, counts=pickup_counts(parcels), clock=self.server.pickup.clock()))
        if role in ('shop', 'sales', 'fulfillment') and path == '/api/portfolio/catalog':
            stock = Stock(self.server.store).snapshot(summary=True)
            available = {p['id']: p['available'] for p in stock['products']}
            return self.send({'products': [{**p, 'available': available.get(p['id'], 0)}
                                           for p in self.server.portfolio['products']]})
        if role in ('sales', 'fulfillment') and path == '/api/portfolio/orders':
            params = parse_qs(query, keep_blank_values=True, max_num_fields=6)
            if any(k not in ('page','page_size','q','state','start','end') or len(v)!=1 for k,v in params.items()):
                raise ValueError('分頁條件不正確')
            values = {k:v[0] for k,v in params.items()}
            for key in ('page','page_size'):
                if key in values: values[key] = int(values[key])
            result = order_page(self.server.store, self.server.portfolio['account_id'], fulfillment_state, **values)
            kols = self.server.kol_module.Kol(self.server.kol_store).list()
            for order in result['orders']:
                attribution = self.server.kol_module.attribute_order(dict(ordered_at=order['ordered_at'], utm_medium=order['utm'].get('medium','')), kols)
                order['kol_attribution'] = dict(id=attribution['kol_id'], name=attribution['kol_name'], reason=attribution['reason'])
            return self.send(result)
        if role == 'sales' and path == '/api/portfolio/overview':
            result = sales(self.server.store, account_id=self.server.portfolio['account_id'])
            counts = order_page(self.server.store, self.server.portfolio['account_id'], fulfillment_state)['state_counts']
            with self.server.store.connect() as db:
                period = db.execute('''SELECT MIN(json_extract(v.normalized,'$.ordered_at')) first,
                    MAX(json_extract(v.normalized,'$.ordered_at')) last FROM current_orders c
                    JOIN order_versions v USING(account_id,order_id,revision) WHERE c.account_id=?''',
                    (self.server.portfolio['account_id'],)).fetchone()
            names = {p['id']: p['name'] for p in self.server.portfolio['products']}
            products = {}
            for line in result['lines']:
                item = products.setdefault(line['product_id'], dict(product_id=line['product_id'],
                    name=names.get(line['product_id'], line['product_name']), quantity=0, amount=Decimal('0')))
                item['quantity'] += line['quantity']
                item['amount'] += Decimal(line['amount'])
            rows = [dict(item, amount=f"{item['amount']:.2f}") for item in products.values()]
            rows.sort(key=lambda item: (-item['quantity'], item['name']))
            shipped = counts.get('shipped', 0)
            return self.send(dict(amount=result['amount'], order_count=result['order_count'],
                sales_quantity=result['sales_quantity'], shipped_count=shipped,
                awaiting_count=max(0, result['order_count'] - shipped), products=rows,
                period=dict(start=period['first'], end=period['last']),
                currency='TWD', scope='simulated_portfolio_orders', rule_version=result['rule_version'], state_counts=counts))
        if role in ('shop', 'sales', 'fulfillment') and path == '/api/portfolio/order':
            order_id = parse_qs(query).get('id', [''])[0]
            detail = self.order_detail(order_id)
            if role == 'shop':
                detail.pop('customer', None)
                detail.pop('delivery', None)
            return self.send(detail)
        if role == 'fulfillment' and path == '/api/portfolio/notes':
            order_id = parse_qs(query).get('order_id', [''])[0]
            self.order_detail(order_id)
            with self.server.store.connect() as db:
                rows = [dict(row) for row in db.execute('''SELECT token,body,created_at FROM portfolio_notes
                    WHERE order_id=? ORDER BY created_at DESC, rowid DESC LIMIT 100''', (order_id,))]
            return self.send({'order_id': order_id, 'notes': rows})
        if role == 'sales' and path == '/api/portfolio/kols':
            return self.send({'kols': self.server.kol_module.Kol(self.server.kol_store).list()})
        if role == 'sales' and path == '/api/portfolio/kol':
            params = parse_qs(query, keep_blank_values=True, max_num_fields=5)
            if any(k not in ('kol_id','start','end','status','page') or len(v)!=1 for k,v in params.items()):
                raise ValueError('KOL 篩選條件不正確')
            return self.send(portfolio_kol_report(self.server, **{k:v[0] for k,v in params.items()}))
        if role == 'fulfillment':
            return super().get(path, query)
        raise HttpError(404, '找不到頁面。')

    def post(self, path, body):
        if self.server.role == 'sales' and path.startswith('/api/portfolio/pickups/'):
            try:
                if path == '/api/portfolio/pickups/clock':
                    return self.server.pickup.advance(body)
                if path == '/api/portfolio/pickups/check':
                    self.server.pickup.tick()
                    return self.server.pickup.clock()
                match = re.fullmatch(r'/api/portfolio/pickups/([a-f0-9]{32})/events', path)
                if match:
                    return self.server.pickup.transition(match[1], body)
                raise HttpError(404, '找不到操作')
            except ConflictError as exc:
                raise HttpError(409, str(exc)) from exc
        if self.server.role == 'sales' and path == '/api/portfolio/kols':
            try:
                return self.server.kol_module.Kol(self.server.kol_store).save(body)
            except self.server.kol_module.ConflictError as exc:
                raise HttpError(409, str(exc)) from None
        try:
            if self.server.role == 'shop' and path == '/api/portfolio/checkout':
                return self.checkout(body)
            if self.server.role == 'fulfillment' and path == '/api/portfolio/notes':
                return self.add_note(body)
        except ConflictError as exc:
            if '庫存不足' in str(exc):
                raise HttpError(409, '可出貨庫存不足。請調整數量；倉管可在原入庫流程補貨並配櫃。') from None
            raise HttpError(409, '訂單或庫存狀態已變動，請重新整理後再試。') from None
        except (ValueError, KeyError):
            raise HttpError(400, '操作內容不正確，請重新整理並檢查選項。') from None
        if self.server.role == 'fulfillment':
            return super().post(path, body)
        raise HttpError(404, '找不到操作。')

    def demo_orders(self):
        with self.server.store.connect() as db:
            ids = [r[0] for r in db.execute('SELECT order_id FROM current_orders WHERE account_id=? ORDER BY rowid DESC',
                                             (self.server.portfolio['account_id'],))]
        report = self.server.kol_module.report(self.server.kol_store,
            account_id=self.server.kol_portfolio['account_id'])
        attributions = {item['order_id']: item for item in report['orders']}
        return [self.order_detail(order_id, attributions) for order_id in ids]

    def order_detail(self, order_id, attributions=None):
        if not re.fullmatch(r'TIDE-(?:[A-F0-9]{16}|[A-F0-9]{32})', order_id):
            raise HttpError(404, '找不到這張訂單。')
        account = self.server.portfolio['account_id']
        with self.server.store.connect() as db:
            db.execute('BEGIN')
            row = db.execute('''SELECT v.normalized FROM current_orders c JOIN order_versions v
                USING(account_id,order_id,revision) WHERE c.account_id=? AND c.order_id=?''', (account, order_id)).fetchone()
            if not row:
                raise HttpError(404, '找不到這張訂單。')
            order = json.loads(row['normalized'])
            shipments = [dict(r) for r in db.execute('''SELECT s.id,s.number,s.state,s.reopen_count,s.lines FROM shipments s
                JOIN fulfillment_groups g ON g.id=s.group_id WHERE g.account_id=? AND g.order_id=?
                ORDER BY s.rowid''', (account, order_id))]
            for shipment in shipments:
                shipment['lines'] = json.loads(shipment['lines'])
            metadata_row = db.execute('SELECT details FROM portfolio_checkout_details WHERE token=?',
                                      (order_id.removeprefix('TIDE-').lower(),)).fetchone()
            metadata = json.loads(metadata_row['details']) if metadata_row else {}
            returns = order_returns(db, account, [order_id])[order_id]
        names = {p['id']: p for p in self.server.portfolio['products']}
        lines = [dict(product_id=line['product_id'], name=names.get(line['product_id'],{}).get('name',line.get('item_name','')),
                      sku=names.get(line['product_id'],{}).get('sku',line.get('external_sku','')), quantity=line['quantity'],
                      unit_price=f"{Decimal(line['amount_cents']) / 100 / line['quantity']:.2f}",
                      amount=f"{line['amount_cents'] // 100}.{line['amount_cents'] % 100:02d}") for line in order['lines']]
        state = fulfillment_state(order, shipments)
        current_shipment = next((shipment for shipment in reversed(shipments)
                                 if shipment['state'] != 'cancelled'), None)
        attribution = self.server.kol_module.attribute_order(order, self.server.kol_module.Kol(self.server.kol_store).list())
        return dict(order_id=order_id, account_id=account, ordered_at=order['ordered_at'], total=f"{sum(line['amount_cents'] for line in order['lines']) // 100}.{sum(line['amount_cents'] for line in order['lines']) % 100:02d}",
                    currency=order.get('currency', 'TWD'), lines=lines, state=state,
                    returns=returns,
                    parcels=self.server.pickup.parcels(order_id=order_id, historical=True),
                    order_status=order['status'], shipping_fee=None, unit_price_basis='line_amount_divided_by_quantity',
                    shipments=[{key: shipment[key] for key in ('id', 'number', 'state', 'reopen_count')} for shipment in shipments],
                    shipment={key: current_shipment[key] for key in ('id', 'number', 'state', 'reopen_count')}
                             if current_shipment else None,
                    customer=metadata.get('customer', {}), delivery=metadata.get('delivery', {}),
                    payment=dict(method=metadata.get('payment_method', '未記錄'), status='模擬付款完成（未收款）'),
                    shipping_method=metadata.get('shipping_method', '未記錄'),
                    utm={**metadata.get('utm', {}), 'medium':order.get('utm_medium','')}, kol_attribution=dict(id=attribution['kol_id'], name=attribution['kol_name'],
                        reason=attribution['reason']) if attribution else None)

    def checkout(self, body):
        token = body.get('token')
        if not isinstance(token, str) or not re.fullmatch(r'[a-f0-9]{32}', token):
            raise ValueError('invalid token')
        cart = body.get('lines')
        if not isinstance(cart, list) or not 1 <= len(cart) <= len(self.server.portfolio['products']):
            raise ValueError('invalid cart')
        known = {p['id']: p for p in self.server.portfolio['products']}
        seen, lines = set(), []
        for item in cart:
            if not isinstance(item, dict) or item.get('product_id') not in known or item['product_id'] in seen:
                raise ValueError('invalid product')
            quantity = item.get('quantity')
            if type(quantity) is not int or not 1 <= quantity <= 5:
                raise ValueError('invalid quantity')
            seen.add(item['product_id'])
            lines.append(dict(product_id=item['product_id'], quantity=quantity,
                              unit_price=known[item['product_id']]['price']))
        lines.sort(key=lambda line: line['product_id'])
        customer = body.get('customer', {})
        delivery = body.get('delivery', {})
        utm = body.get('utm', {})
        if not all(isinstance(value, dict) for value in (customer, delivery, utm)):
            raise ValueError('invalid checkout details')
        def clean(source, field, maximum):
            value = source.get(field, '')
            if not isinstance(value, str) or len(value.strip()) > maximum:
                raise ValueError('invalid checkout field')
            return value.strip()
        details = dict(
            customer={key: clean(customer, key, limit) for key, limit in
                      (('name', 80), ('email', 160), ('phone', 40))},
            delivery={key: clean(delivery, key, limit) for key, limit in
                      (('recipient', 80), ('address', 250))},
            utm={key: clean(utm, key, 200) for key in ('source', 'medium', 'campaign')},
            payment_method=clean(body, 'payment_method', 40),
            shipping_method=clean(body, 'shipping_method', 40))
        if details['payment_method'] not in ('', '不收款', '模擬付款', '模擬信用卡', '模擬貨到付款', '模擬銀行轉帳') or \
                details['shipping_method'] not in ('', '宅配', '超商取貨'):
            raise ValueError('invalid checkout method')
        if not details['customer']['name'] or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', details['customer']['email']) or \
                not details['delivery']['recipient'] or not details['delivery']['address'] or \
                not details['payment_method'] or not details['shipping_method']:
            raise ValueError('incomplete checkout details')
        canonical = json.dumps(lines, sort_keys=True)
        details_json = json.dumps(details, ensure_ascii=False, sort_keys=True)
        with self.server.store.connect() as db:
            existing_checkout = db.execute('SELECT 1 FROM portfolio_checkouts WHERE token=?', (token,)).fetchone()
        if not existing_checkout:
            available = {item['id']: item['available'] for item in Stock(self.server.store).snapshot(summary=True)['products']}
            if any(line['quantity'] > available.get(line['product_id'], 0) for line in lines):
                raise ConflictError('可出貨庫存不足')
        with self.server.store.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS portfolio_checkouts(token TEXT PRIMARY KEY, cart TEXT NOT NULL, ordered_at TEXT NOT NULL)')
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT cart,ordered_at FROM portfolio_checkouts WHERE token=?', (token,)).fetchone()
            if row and row['cart'] != canonical:
                raise ConflictError('token reused with different cart')
            if not row:
                ordered_at = datetime.now(timezone.utc).isoformat(timespec='seconds')
                db.execute('INSERT INTO portfolio_checkouts VALUES(?,?,?)', (token, canonical, ordered_at))
                db.execute('INSERT INTO portfolio_checkout_details(token,details) VALUES(?,?)', (token, details_json))
            else:
                ordered_at = row['ordered_at']
                existing = db.execute('SELECT details FROM portfolio_checkout_details WHERE token=?', (token,)).fetchone()
                if existing and existing['details'] != details_json:
                    raise ConflictError('token reused with different details')
        order_id = 'TIDE-' + token.upper()
        Orders(self.server.store).receive(dict(operation_id=operation('checkout/' + token),
            account_id=self.server.portfolio['account_id'], order_id=order_id, ordered_at=ordered_at,
            customer_ref='TIDE-CUST-' + token[:8].upper(), kol_ref='',
            utm_medium=details['utm']['medium'], lines=lines))
        mirror_operations_order(self.server, order_id, ordered_at, lines, details)
        return self.order_detail(order_id)

    def add_note(self, body):
        order_id, token, note = body.get('order_id'), body.get('token'), body.get('body')
        self.order_detail(order_id)
        if not isinstance(token, str) or not re.fullmatch(r'[a-f0-9]{32}', token):
            raise ValueError('invalid note token')
        if not isinstance(note, str) or not 1 <= len(note.strip()) <= 500:
            raise ValueError('invalid note')
        note = note.strip()
        with self.server.store.connect() as db:
            db.execute('INSERT OR IGNORE INTO portfolio_notes(token,order_id,body,created_at) VALUES(?,?,?,?)',
                       (token, order_id, note, datetime.now(timezone.utc).isoformat(timespec='seconds')))
            row = db.execute('SELECT token,order_id,body,created_at FROM portfolio_notes WHERE token=?', (token,)).fetchone()
            if row['order_id'] != order_id or row['body'] != note:
                raise ConflictError('note token reused with different content')
        return dict(row)


def create_portfolio_server(database, kol_database, port=8821, kol_port=8822,
                            sales_port=8823, fulfillment_port=8824, seed_sample=True, pickup_simulation=False):
    database, kol_database = Path(database).resolve(), Path(kol_database).resolve()
    forbidden = {(ROOT / '.local' / 'workspace.sqlite3').resolve(),
                 (OPERATIONS_ROOT / '.local' / 'workspace.sqlite3').resolve(),
                 (ROOT.parent / '.local' / 'workspace.sqlite3').resolve()}
    if database in forbidden or kol_database in forbidden or database == kol_database:
        raise ValueError('Portfolio databases must be separate from normal workspaces and each other')
    server = create_server(database, port=port)
    supporting = []
    try:
        demo = localize_warehouse(server.store, seed_warehouse(server.store))
        with server.store.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS portfolio_checkouts(
                token TEXT PRIMARY KEY, cart TEXT NOT NULL, ordered_at TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS portfolio_notes(
                token TEXT PRIMARY KEY, order_id TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS portfolio_checkout_details(
                token TEXT PRIMARY KEY, details TEXT NOT NULL)''')
        pickup = Pickup(server.store, demo['account_id'], simulation=pickup_simulation)
        op_store_module, op_catalogue, op_orders, op_kol, op_server = load_operations()
        kol_store = op_store_module.Store(kol_database)
        kol_portfolio = seed_kol(kol_store, op_catalogue, op_orders, op_kol)
        extend_catalogue(server.store, demo, kol_store, op_catalogue, kol_portfolio)
        kol_server = op_server.create_server(kol_database, port=kol_port)
        supporting.append(kol_server)
        sales_server = create_server(database, port=sales_port)
        supporting.append(sales_server)
        fulfillment_server = create_server(database, port=fulfillment_port)
        supporting.append(fulfillment_server)
        fulfillment_url = f'http://127.0.0.1:{fulfillment_server.server_port}/'
        sales_url = f'http://127.0.0.1:{sales_server.server_port}/'
        class PortfolioOperationsHandler(op_server.Handler):
            def get(self, path, query):
                if path == '/':
                    return self.send(workspace_page(OPERATIONS_ROOT, 'sales', fulfillment_url,
                                                    f'http://127.0.0.1:{server.server_port}/',
                                                    sales_url, f'http://127.0.0.1:{kol_server.server_port}/'),
                                     mime='text/html; charset=utf-8')
                if path in ('/admin-shell.css', '/admin-workspace.css', '/admin-shell.js', '/theme-a.css'):
                    mime = 'text/javascript' if path.endswith('.js') else 'text/css'
                    return self.send((ROOT / 'portfolio' / path.lstrip('/')).read_bytes(),
                                     mime=mime + '; charset=utf-8')
                return super().get(path, query)
        kol_server.RequestHandlerClass = PortfolioOperationsHandler
        for instance, role in ((server, 'shop'), (sales_server, 'sales'), (fulfillment_server, 'fulfillment')):
            instance.RequestHandlerClass = PortfolioHandler
            instance.role = role
            instance.portfolio = demo
            instance.pickup = pickup
            instance.kol_store = kol_store
            instance.kol_module = op_kol
            instance.kol_orders = op_orders
            instance.kol_portfolio = kol_portfolio
            instance.kol_url = f'http://127.0.0.1:{kol_server.server_port}/'
            instance.fulfillment_url = fulfillment_url
            instance.sales_url = sales_url
            instance.shop_url = f'http://127.0.0.1:{server.server_port}/'
        if seed_sample:
            seed_sample_order(server.store, demo)
        sync_existing_orders(server)
        pickup.tick()
        pickup_stop = threading.Event()
        def pickup_worker():
            while not pickup_stop.wait(30):
                try:
                    pickup.tick()
                except Exception:
                    import logging
                    logging.exception('Local simulated pickup reminder check failed')
        pickup_thread = threading.Thread(target=pickup_worker, daemon=True)
        pickup_thread.start()
        threads = [threading.Thread(target=instance.serve_forever, daemon=True) for instance in supporting]
        for thread in threads:
            thread.start()
        server.sales_url = sales_url
        server.fulfillment_url = fulfillment_url
        close_warehouse = server.server_close
        def close_all():
            pickup_stop.set()
            pickup_thread.join(timeout=5)
            for instance in supporting:
                instance.shutdown()
            for thread in threads:
                thread.join(timeout=5)
            for instance in supporting:
                instance.server_close()
            close_warehouse()
        server.server_close = close_all
        return server
    except Exception:
        for instance in supporting:
            instance.server_close()
        server.server_close()
        raise


def main():
    parser = argparse.ArgumentParser(description='Isolated StockPilot portfolio demo')
    parser.add_argument('--database', type=Path, default=ROOT / '.local' / 'portfolio-showcase.sqlite3')
    parser.add_argument('--kol-database', type=Path, default=ROOT / '.local' / 'portfolio-showcase-kol.sqlite3')
    parser.add_argument('--port', type=int, default=8821)
    parser.add_argument('--kol-port', type=int, default=8822)
    parser.add_argument('--sales-port', type=int, default=8823)
    parser.add_argument('--fulfillment-port', type=int, default=8824)
    parser.add_argument('--no-sample', action='store_true', help='Do not add the initial sample order to an existing scale fixture')
    parser.add_argument('--pickup-simulation', action='store_true', help='Enable persistent forward-only clock in an isolated pickup-dashboard demo directory')
    args = parser.parse_args()
    if args.pickup_simulation and not any(part.startswith('pickup-dashboard-') for part in args.database.resolve().parts):
        parser.error('Simulation clock requires an isolated pickup-dashboard-* directory')
    local = (ROOT / '.local').resolve()
    if not args.database.resolve().is_relative_to(local) or not args.kol_database.resolve().is_relative_to(local):
        parser.error('Both demo databases must be inside this copy of the warehouse project: .local/')
    server = create_portfolio_server(args.database, args.kol_database, args.port, args.kol_port,
                                     args.sales_port, args.fulfillment_port, seed_sample=not args.no_sample, pickup_simulation=args.pickup_simulation)
    print(f'Storefront: http://127.0.0.1:{server.server_port}/', flush=True)
    print(f'Sales dashboard: {server.sales_url}', flush=True)
    print(f'Fulfillment workspace: {server.fulfillment_url}', flush=True)
    print(f'Existing KOL workspace: {server.kol_url}', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
