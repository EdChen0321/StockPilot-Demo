"""Read actual shipment/return cycles without changing fulfillment history."""


def order_returns(db, account_id, order_ids):
    summaries = {identifier: dict(state='none', shipped=0, returned=0,
                                 not_returned=0, pending=0, released=0, items=[])
                 for identifier in order_ids}
    if not summaries:
        return summaries
    placeholders = ','.join('?' for _ in summaries)
    rows = db.execute(f'''SELECT g.order_id,u.product_id,count(*) shipped,
        count(r.ship_event_id) returned,count(x.ship_event_id) released
        FROM fulfillment_groups g JOIN shipments s ON s.group_id=g.id
        JOIN stock_events e ON e.shipment_id=s.id AND e.kind='ship'
        JOIN stock_units u ON u.id=e.unit_id
        LEFT JOIN stock_returns r ON r.ship_event_id=e.id
        LEFT JOIN stock_return_releases x ON x.ship_event_id=r.ship_event_id
        WHERE g.account_id=? AND g.order_id IN ({placeholders})
          AND NOT EXISTS (SELECT 1 FROM stock_ship_reversals v WHERE v.ship_event_id=e.id)
        GROUP BY g.order_id,u.product_id ORDER BY g.order_id,u.product_id''',
        [account_id, *summaries]).fetchall()
    for row in rows:
        summary = summaries[row['order_id']]
        item = dict(product_id=row['product_id'], shipped=row['shipped'],
                    returned=row['returned'], released=row['released'],
                    pending=row['returned'] - row['released'],
                    not_returned=row['shipped'] - row['returned'])
        summary['items'].append(item)
        for key in ('shipped', 'returned', 'not_returned', 'pending', 'released'):
            summary[key] += item[key]
    for summary in summaries.values():
        if summary['returned']:
            summary['state'] = 'full' if summary['returned'] == summary['shipped'] else 'partial'
    return summaries
