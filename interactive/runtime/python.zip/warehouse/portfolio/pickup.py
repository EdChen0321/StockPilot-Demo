"""Local-only parcel ledger. No network, mail, inventory or payment side effects."""
import json
from datetime import datetime, timedelta, timezone, date
from uuid import uuid4

from ops.store import ConflictError

TAIPEI = timezone(timedelta(hours=8))
LABELS = {'in_transit': '運送中', 'awaiting_pickup': '已到店待取',
          'collected': '已取件', 'returning': '退回途中', 'returned': '已退回',
          'delivered': '宅配已送達'}
TRANSITIONS = {'in_transit': {'awaiting_pickup', 'returning', 'delivered'},
               'awaiting_pickup': {'collected', 'returning'}, 'returning': {'returned'},
               'collected': set(), 'returned': set(), 'delivered': set()}


def instant(value):
    if not isinstance(value, str):
        raise ValueError('請提供包含時區的事件時間')
    try:
        result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    except ValueError:
        raise ValueError('事件時間格式不正確') from None
    if result.tzinfo is None:
        raise ValueError('事件時間必須包含時區；不猜測未知時間')
    return result.astimezone(timezone.utc)


def iso(value):
    return value.astimezone(timezone.utc).isoformat()


def date_range(start='', end=''):
    for value in (start, end):
        if value:
            if date.fromisoformat(value).isoformat() != value:
                raise ValueError('日期格式須為 YYYY-MM-DD')
    if start and end and start > end:
        raise ValueError('起日不可晚於迄日')


def in_period(value, start='', end=''):
    if not start and not end:
        return True
    if not value:
        return False
    day = instant(value).astimezone(TAIPEI).date().isoformat()
    return (not start or day >= start) and (not end or day <= end)


class Pickup:
    def __init__(self, store, account, simulation=False):
        self.store, self.account, self.simulation = store, account, simulation
        with store.connect() as db:
            db.executescript('''
            CREATE TABLE IF NOT EXISTS portfolio_parcels(
                id TEXT PRIMARY KEY, shipment_id TEXT NOT NULL REFERENCES shipments(id),
                dispatch_revision INTEGER NOT NULL, account_id TEXT NOT NULL, order_id TEXT NOT NULL,
                mode TEXT NOT NULL, state TEXT NOT NULL, shipped_at TEXT, arrival_at TEXT,
                arrival_event_id TEXT, version INTEGER NOT NULL DEFAULT 0, last_event_at TEXT,
                UNIQUE(shipment_id,dispatch_revision),
                FOREIGN KEY(account_id,order_id) REFERENCES current_orders(account_id,order_id));
            CREATE TABLE IF NOT EXISTS portfolio_parcel_events(
                id TEXT PRIMARY KEY, parcel_id TEXT NOT NULL REFERENCES portfolio_parcels(id),
                token TEXT NOT NULL UNIQUE, kind TEXT NOT NULL, occurred_at TEXT,
                recorded_at TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS portfolio_pickup_reminders(
                id TEXT PRIMARY KEY, parcel_id TEXT NOT NULL REFERENCES portfolio_parcels(id),
                arrival_event_id TEXT NOT NULL UNIQUE REFERENCES portfolio_parcel_events(id),
                due_at TEXT NOT NULL, checked_at TEXT NOT NULL, recorded_at TEXT NOT NULL,
                channel TEXT NOT NULL CHECK(channel='simulated_email'));
            CREATE TABLE IF NOT EXISTS portfolio_pickup_clock(
                account_id TEXT PRIMARY KEY REFERENCES accounts(id), instant TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS portfolio_pickup_clock_events(
                token TEXT PRIMARY KEY, account_id TEXT NOT NULL, before_at TEXT NOT NULL,
                after_at TEXT NOT NULL, recorded_at TEXT NOT NULL);
            ''')

    def _now(self, db):
        if self.simulation:
            row = db.execute('SELECT instant FROM portfolio_pickup_clock WHERE account_id=?', (self.account,)).fetchone()
            if row:
                return instant(row[0])
        return datetime.now(timezone.utc)

    def clock(self):
        with self.store.connect() as db:
            return {'now': iso(self._now(db)), 'simulation': self.simulation, 'timezone': 'Asia/Taipei'}

    def _sync(self, db):
        for row in db.execute('''SELECT s.*,g.account_id,g.order_id,d.details FROM shipments s
            JOIN fulfillment_groups g ON g.id=s.group_id
            LEFT JOIN portfolio_checkout_details d ON d.token=lower(substr(g.order_id,6))
            WHERE g.account_id=? AND s.state='shipped' ''', (self.account,)).fetchall():
            existing = db.execute('SELECT id FROM portfolio_parcels WHERE shipment_id=? AND dispatch_revision=?',
                                  (row['id'], row['reopen_count'])).fetchone()
            if existing:
                continue
            method = json.loads(row['details'] or '{}').get('shipping_method', '')
            mode = 'pickup' if method == '超商取貨' else 'delivery' if method == '宅配' else 'unknown'
            pid, eid = uuid4().hex, uuid4().hex
            db.execute('''INSERT INTO portfolio_parcels(id,shipment_id,dispatch_revision,account_id,
                order_id,mode,state,shipped_at,last_event_at) VALUES(?,?,?,?,?,?,'in_transit',?,?)''',
                       (pid, row['id'], row['reopen_count'], self.account, row['order_id'], mode, row['shipped_at'], row['shipped_at']))
            db.execute('INSERT INTO portfolio_parcel_events VALUES(?,?,?,?,?,?,?)',
                       (eid, pid, 'dispatch/'+pid, 'in_transit', row['shipped_at'],
                        iso(datetime.now(timezone.utc)), json.dumps({'source': 'existing_shipment', 'mode': mode})))

    def _remind(self, db):
        checked = self._now(db)
        rows = db.execute('''SELECT p.* FROM portfolio_parcels p JOIN shipments s ON s.id=p.shipment_id
            WHERE p.account_id=? AND p.mode='pickup' AND p.state='awaiting_pickup'
            AND p.arrival_at IS NOT NULL AND s.state='shipped' AND s.reopen_count=p.dispatch_revision''', (self.account,)).fetchall()
        for row in rows:
            due = instant(row['arrival_at']) + timedelta(hours=96)
            if checked >= due:
                db.execute('''INSERT OR IGNORE INTO portfolio_pickup_reminders
                    VALUES(?,?,?,?,?,?, 'simulated_email')''',
                           (uuid4().hex, row['id'], row['arrival_event_id'], iso(due), iso(checked), iso(datetime.now(timezone.utc))))

    def tick(self):
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._sync(db)
            self._remind(db)

    def advance(self, body):
        if not self.simulation:
            raise ValueError('此資料庫未啟用隔離模擬時鐘')
        hours, token = body.get('hours'), body.get('token')
        if type(hours) is not int or hours not in (24, 96) or not isinstance(token, str) or not 8 <= len(token) <= 100:
            raise ValueError('模擬時間僅可前進 24 或 96 小時，並須提供操作識別碼')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM portfolio_pickup_clock_events WHERE token=?', (token,)).fetchone()
            if old:
                if old['account_id'] != self.account or instant(old['after_at'])-instant(old['before_at']) != timedelta(hours=hours):
                    raise ConflictError('操作識別碼已用於其他時鐘操作')
            else:
                before = self._now(db)
                after = before + timedelta(hours=hours)
                db.execute('INSERT OR REPLACE INTO portfolio_pickup_clock VALUES(?,?)', (self.account, iso(after)))
                db.execute('INSERT INTO portfolio_pickup_clock_events VALUES(?,?,?,?,?)',
                           (token, self.account, iso(before), iso(after), iso(datetime.now(timezone.utc))))
            self._sync(db)
            self._remind(db)
        return self.clock()

    def transition(self, pid, body):
        state, token = body.get('state'), body.get('token')
        if state not in LABELS or not isinstance(token, str) or not 8 <= len(token) <= 100:
            raise ValueError('請提供有效的物流狀態與操作識別碼')
        occurred = instant(body.get('occurred_at'))
        note = body.get('note', '')
        if not isinstance(note, str) or len(note) > 500:
            raise ValueError('備註最多 500 字')
        payload = json.dumps({'state': state, 'occurred_at': iso(occurred), 'note': note}, sort_keys=True)
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            self._sync(db)
            row = db.execute('''SELECT p.*,s.state shipment_state,s.reopen_count FROM portfolio_parcels p
                JOIN shipments s ON s.id=p.shipment_id WHERE p.id=? AND p.account_id=?''', (pid, self.account)).fetchone()
            if not row:
                raise ValueError('找不到此包裹')
            old = db.execute('SELECT parcel_id,payload FROM portfolio_parcel_events WHERE token=?', (token,)).fetchone()
            if old:
                if old['parcel_id'] != pid or old['payload'] != payload:
                    raise ConflictError('操作識別碼已用於其他事件')
                return {'id': pid, 'replayed': True}
            if row['shipment_state'] != 'shipped' or row['reopen_count'] != row['dispatch_revision']:
                raise ConflictError('原出貨已重開或撤回，此包裹僅供歷史查閱')
            if type(body.get('version')) is not int or row['version'] != body['version']:
                raise ConflictError('包裹已更新，請重新整理')
            if state not in TRANSITIONS[row['state']]:
                raise ConflictError('不允許此物流狀態轉換；不重複建立到店事件')
            if state in ('awaiting_pickup', 'collected') and row['mode'] != 'pickup':
                raise ValueError('僅配送方式明確為超商取貨的包裹可記錄到店／取件')
            if state == 'delivered' and row['mode'] != 'delivery':
                raise ValueError('僅宅配包裹可記錄宅配送達')
            if occurred > self._now(db) or (row['last_event_at'] and occurred < instant(row['last_event_at'])):
                raise ValueError('事件時間不可早於上一事件或晚於目前檢查時間')
            eid = uuid4().hex
            db.execute('INSERT INTO portfolio_parcel_events VALUES(?,?,?,?,?,?,?)',
                       (eid, pid, token, state, iso(occurred), iso(datetime.now(timezone.utc)), payload))
            db.execute('UPDATE portfolio_parcels SET state=?,version=version+1,last_event_at=? WHERE id=?', (state, iso(occurred), pid))
            if state == 'awaiting_pickup':
                db.execute('UPDATE portfolio_parcels SET arrival_at=?,arrival_event_id=? WHERE id=?', (iso(occurred), eid, pid))
            self._remind(db)
        return {'id': pid, 'replayed': False}

    def parcels(self, *, start='', end='', filter='all', order_id='', historical=False):
        date_range(start, end)
        if filter not in ('all', *LABELS, 'overdue', 'reminded', 'unknown'):
            raise ValueError('未知包裹篩選條件')
        self.tick()
        with self.store.connect() as db:
            db.execute('BEGIN')
            checked = self._now(db)
            rows = db.execute('''SELECT p.*,s.number,s.state shipment_state,s.reopen_count,
                json_extract(v.normalized,'$.ordered_at') ordered_at FROM portfolio_parcels p
                JOIN shipments s ON s.id=p.shipment_id
                JOIN current_orders c ON c.account_id=p.account_id AND c.order_id=p.order_id
                JOIN order_versions v USING(account_id,order_id,revision)
                WHERE p.account_id=? ORDER BY p.rowid DESC''', (self.account,)).fetchall()
            reminders = {r['arrival_event_id']: dict(r) for r in db.execute('SELECT * FROM portfolio_pickup_reminders')}
            warehouse_returns = {r['shipment_id']: dict(r) for r in db.execute('''
                SELECT e.shipment_id,count(*) received_units,
                    sum(CASE WHEN x.ship_event_id IS NULL THEN 1 ELSE 0 END) held_units
                FROM stock_returns r JOIN stock_events e ON e.id=r.ship_event_id
                LEFT JOIN stock_return_releases x ON x.ship_event_id=r.ship_event_id
                GROUP BY e.shipment_id''')}
            events = {}
            for r in db.execute('SELECT * FROM portfolio_parcel_events ORDER BY rowid'):
                events.setdefault(r['parcel_id'], []).append(dict(r))
        result = []
        for row in rows:
            item = dict(row)
            item['active'] = row['shipment_state'] == 'shipped' and row['reopen_count'] == row['dispatch_revision']
            if not historical and not item['active']:
                continue
            if (order_id and row['order_id'] != order_id) or not in_period(row['ordered_at'], start, end):
                continue
            reminder = reminders.get(row['arrival_event_id'])
            item['overdue'] = bool(item['active'] and row['state'] == 'awaiting_pickup' and row['arrival_at'] and checked >= instant(row['arrival_at']) + timedelta(hours=96))
            item['reminded'] = bool(item['active'] and row['state'] == 'awaiting_pickup' and reminder)
            item['reminder'] = reminder
            item['warehouse_returns'] = warehouse_returns.get(row['shipment_id'], {'received_units': 0, 'held_units': 0})
            item['events'] = events.get(row['id'], [])
            item['label'] = LABELS[row['state']]
            item['allowed'] = sorted(TRANSITIONS[row['state']] - ({'awaiting_pickup', 'collected'} if row['mode'] != 'pickup' else set()) - ({'delivered'} if row['mode'] != 'delivery' else set())) if item['active'] else []
            if filter == 'all' or (filter in LABELS and row['state'] == filter) or (filter in ('overdue', 'reminded') and item[filter]) or (filter == 'unknown' and row['mode'] == 'unknown'):
                result.append(item)
        return result


def counts(parcels):
    return {key: sum(bool(p[key]) if key in ('overdue', 'reminded') else p['state'] == key for p in parcels)
            for key in (*LABELS, 'overdue', 'reminded')}
