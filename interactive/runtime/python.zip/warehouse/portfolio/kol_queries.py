"""KOL settings from Operations; commerce facts from the owning warehouse orders."""
import json
from datetime import date, datetime, timedelta, timezone


def money(cents):
    return f'{cents // 100}.{cents % 100:02d}'


def report(server, *, kol_id='', start='', end='', status='all', page='1'):
    page = int(page)
    if page < 1 or page > 1000000 or status not in ('all', 'active', 'cancelled'):
        raise ValueError('頁碼或訂單狀態不正確')
    for value in (start, end):
        if value: date.fromisoformat(value)
    if start and end and start > end:
        raise ValueError('起日不可晚於迄日')
    kols = server.kol_module.Kol(server.kol_store).list()
    groups = [*server.kol_module.system_groups(), *kols]
    if kol_id and kol_id not in {g['id'] for g in groups}:
        raise ValueError('找不到 KOL')
    with server.store.connect() as db:
        originals = [json.loads(r[0]) for r in db.execute('''SELECT v.normalized
            FROM current_orders c JOIN order_versions v USING(account_id,order_id,revision)
            WHERE c.account_id=?''', (server.portfolio['account_id'],))]
    orders = []
    for original in originals:
        day = datetime.fromisoformat(original['ordered_at']).astimezone(timezone(timedelta(hours=8))).date().isoformat()
        if (start and day < start) or (end and day > end): continue
        lines = [dict(product_id=l['product_id'], sku=l.get('external_sku',''),
            name=l.get('item_name',''), quantity=l['quantity'], amount=money(l['amount_cents'])) for l in original['lines']]
        orders.append(dict(order_id=original['order_id'], ordered_at=original['ordered_at'], day=day,
            status=original['status'], lines=lines, quantity=sum(l['quantity'] for l in lines),
            cents=sum(l['amount_cents'] for l in original['lines']),
            **server.kol_module.attribute_order(original,kols)))
    def summary(selected):
        active = [o for o in selected if o['status']=='active']
        return dict(order_count=len(active), quantity=sum(o['quantity'] for o in active),
            total=money(sum(o['cents'] for o in active)), cancelled_count=sum(o['status']=='cancelled' for o in selected))
    group_rows = [dict(g, **summary([o for o in orders if o['kol_id']==g['id']])) for g in groups]
    selected = [o for o in orders if not kol_id or o['kol_id']==kol_id]
    visible = [o for o in selected if status=='all' or o['status']==status]
    visible.sort(key=lambda o:(datetime.fromisoformat(o['ordered_at']),o['order_id']),reverse=True)
    pages = max(1,(len(visible)+24)//25); page=min(page,pages)
    rows = [dict(o,total=money(o['cents'])) for o in visible[(page-1)*25:page*25]]
    for row in rows: row.pop('cents')
    return dict(groups=group_rows,summary=summary(selected),orders=rows,total=len(visible),page=page,pages=pages,
        period=dict(start=start or min((o['day'] for o in orders),default=''),end=end or max((o['day'] for o in orders),default='')),
        filters=dict(kol_id=kol_id,start=start,end=end,status=status),rule_version='utm_medium_exact_v1',
        workspace_url=server.kol_url+'#kol',shop_url=server.shop_url)
