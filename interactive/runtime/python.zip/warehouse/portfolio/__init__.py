"""Local English portfolio demo, isolated from normal workspaces."""
