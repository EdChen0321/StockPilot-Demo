"""Explicit, repeatable synthetic expansion. No writes to the original project.

Run after taking a SQLite backup: python -m portfolio.showcase_seed
Business entities use original commands; only presentation metadata uses SQL.
"""
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ops.catalogue import Catalogue
from ops.locations import Locations
from ops.orders import Orders
from ops.stock import Stock
from .server import ROOT, create_portfolio_server, load_operations, mirror_operations_order

PREFIX = 'showcase-20261110'
VARIANTS = [
    ('TIDE-SWIMBAIT-90', '90mm 多節硬式泳餌', 'Compact jointed swimbait', 'TIDE-SWIMBAIT', '90 mm / 14 g', '980.00', 40,
     'A compact olive-silver profile for a lighter setup. Retrieve slowly with short pauses.'),
    ('TIDE-SWIMBAIT-140', '140mm 多節硬式泳餌', 'Long-profile swimbait', 'TIDE-SWIMBAIT', '140 mm / 32 g', '1680.00', 32,
     'A longer jointed profile for open-water presentations. Match your rod rating to the 32 g weight.'),
    ('TIDE-FROG-45', '45mm 浮水青蛙餌', 'Pocket frog', 'TIDE-FROG', '45 mm / 7 g', '220.00', 36,
     'A smaller floating frog for short casts along cover. Pause between gentle pulls.'),
    ('TIDE-FROG-65', '65mm 浮水青蛙餌', 'Cover frog', 'TIDE-FROG', '65 mm / 16 g', '290.00', 28,
     'A fuller surface profile with a skirted tail. Work the edge of vegetation with controlled twitches.'),
    ('TIDE-WORM-3', '3 吋棒蟲軟餌／8 入', '3-inch finesse worms', 'TIDE-WORM', '3 inch / 8 pieces', '180.00', 2,
     'Eight compact straight-tail worms for a subtle presentation. Watermelon and smoke finishes.'),
    ('TIDE-WORM-5', '5 吋棒蟲軟餌／5 入', '5-inch stick worms', 'TIDE-WORM', '5 inch / 5 pieces', '240.00', 0,
     'A longer straight-tail profile for slow presentations. This size is currently awaiting restock.'),
]


def seed(server):
    catalogue, stock, locations = Catalogue(server.store), Stock(server.store), Locations(server.store)
    _, op_catalogue, op_orders, op_kol, _ = load_operations()
    mirror_catalogue = op_catalogue.Catalogue(server.kol_store)
    products = []
    for sku, name, english, family, spec, price, quantity, description in VARIANTS:
        product = catalogue.create(dict(operation_id=f'{PREFIX}/product/{sku}', name=name, sku=sku,
            barcode=sku, specification=spec, kind='product', attributes={}))
        mirrored = mirror_catalogue.create(dict(operation_id=f'{PREFIX}/product/{sku}', name=name,
            sku=sku, barcode=sku, specification=spec, kind='product', attributes={}))
        item = dict(id=product['id'], sku=sku, name=name, en_name=english, family=family,
            specification=spec, price=price, description=description, en_description=description,
            image_note='Family reference image; the selected size and pack are listed in the details.')
        products.append(item)
        with server.store.connect() as db:
            db.execute('INSERT OR IGNORE INTO portfolio_products VALUES(?,?)', (sku, json.dumps(item, ensure_ascii=False)))
        if sku not in {p['sku'] for p in server.portfolio['products']}:
            server.portfolio['products'].append(item)
        server.kol_portfolio['products'][sku] = mirrored['id']
    place = locations.save(dict(operation_id=f'{PREFIX}/place', address='TIDE', position='B-01',
        name='規格系列展示儲位', can_import=True, can_export=True, can_return=True, entry_state='import',
        comment='合成示範資料，非真實庫存'))
    receipt = stock.receipt(dict(operation_id=f'{PREFIX}/receipt', number='DEMO-20261110-RESTOCK',
        source='虛構供應商 Tide Workshop', freight='0', tax='0',
        lines=[dict(product_id=p['id'], quantity=v[6], unit_price='50.00') for p,v in zip(products,VARIANTS) if v[6]]))
    stock.confirm_receipt(receipt['id'], dict(operation_id=f'{PREFIX}/confirm'))
    locations.assign(dict(operation_id=f'{PREFIX}/putaway', receipt_id=receipt['id'], place_id=place['id'],
        quantity=sum(v[6] for v in VARIANTS)))
    for name, medium, campaign in [('Mira Brook (Demo)', 'mira-bank', 'Bank fishing collection'),
                                    ('Noah Reed (Demo)', 'noah-cover', 'Surface collection')]:
        op_kol.Kol(server.kol_store).save(dict(operation_id=f'{PREFIX}/kol/{medium}', name=name,
            platforms='manual', started_at='2026-01-01T00:00:00+00:00', utms=medium, keep_case=False,
            campaign_name=campaign, comment='虛構創作者與活動，非真實商業成效'))
    outcomes = ['placed','draft','allocated','picked','staged','shipped','partially_shipped','cancelled']
    records = []
    for i in range(24):
        token=f'de0020261110{i+1:020x}'
        order_id='TIDE-'+token.upper()
        p=products[i%4]
        target=outcomes[i%8]
        lines=[dict(product_id=p['id'], quantity=2 if target=='partially_shipped' else 1, unit_price=p['price'])]
        if i%4==0:
            other=products[(i+1)%4]
            lines.append(dict(product_id=other['id'], quantity=1, unit_price=other['price']))
        ordered_at=(datetime(2026,11,2,9,tzinfo=timezone(timedelta(hours=8)))+timedelta(hours=i*7)).isoformat()
        customer=f'Demo Angler {i%8+1:02d}'
        medium=['alex-tide','mira-bank','noah-cover',''][i%4]
        details=dict(customer=dict(name=customer,email=f'angler{i%8+1:02d}@example.invalid',phone='',reference=f'DEMO-CUSTOMER-{i%8+1:02d}'),
            delivery=dict(recipient=customer,address=f'Fictional pickup point {i%3+1}'),
            payment_method='模擬付款',shipping_method='超商取貨' if i%2 else '宅配',
            utm=dict(source='demo',medium=medium,campaign='showcase-collection'))
        with server.store.connect() as db:
            db.execute('INSERT OR IGNORE INTO portfolio_checkouts VALUES(?,?,?)', (token,json.dumps(lines,sort_keys=True),ordered_at))
            db.execute('INSERT OR IGNORE INTO portfolio_checkout_details VALUES(?,?)', (token,json.dumps(details,ensure_ascii=False)))
        Orders(server.store).receive(dict(operation_id=f'{PREFIX}/order/{i}', account_id=server.portfolio['account_id'],
            order_id=order_id,ordered_at=ordered_at,customer_ref=f'DEMO-CUSTOMER-{i%8+1:02d}',utm_medium=medium,lines=lines))
        mirror_operations_order(server,order_id,ordered_at,lines,details)
        if target=='cancelled':
            for service, account in [(Orders(server.store),server.portfolio['account_id']),
                                     (op_orders.Orders(server.kol_store),server.kol_portfolio['account_id'])]:
                service.cancel(dict(operation_id=f'{PREFIX}/cancel/{i}',account_id=account,order_id=order_id,
                                    expected_revision=1,reason='虛構顧客取消示範'))
        elif target!='placed':
            shipment=stock.shipment(dict(operation_id=f'{PREFIX}/shipment/{i}',account_id=server.portfolio['account_id'],
                order_id=order_id,number='DEMO-SHIP-'+str(i+1).zfill(3)))
            if target=='partially_shipped':
                stock.update_shipment_lines(shipment['id'],dict(operation_id=f'{PREFIX}/partial/{i}',expected_reopen_count=0,expected_lines=shipment['lines'],
                    lines=[dict(product_id=p['id'],quantity=1)]))
            actions={'draft':[],'allocated':['allocate'],'picked':['allocate','pick'],
                'staged':['allocate','pick','deduct'],'shipped':['allocate','pick','ship'],
                'partially_shipped':['allocate','pick','ship']}[target]
            for action in actions:
                stock.transition(shipment['id'], action, dict(operation_id=f'{PREFIX}/{action}/{i}',expected_reopen_count=0))
        records.append(dict(order_id=order_id,state=target,customer=customer))
    manifest=dict(batch=PREFIX,synthetic=True,product_skus=[p['sku'] for p in products],
        added_orders=records,added_customer_profiles=8,added_kols=2,receipt=receipt['id'],place=place['id'])
    return manifest


def main():
    server=create_portfolio_server(ROOT/'.local/portfolio-showcase.sqlite3',ROOT/'.local/portfolio-showcase-kol.sqlite3',0,0,0,0)
    try:
        manifest=seed(server)
        path=ROOT/'.local/showcase-20261110-manifest.json'
        path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        print(f'Added/reused {len(manifest["product_skus"])} SKUs, 24 synthetic orders; manifest: {path.name}')
    finally:
        server.server_close()

if __name__=='__main__': main()
