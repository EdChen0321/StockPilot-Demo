"""Bounded portfolio lists; reuse the warehouse's shipment-state derivation."""
import json
from datetime import date
from .order_returns import order_returns


def order_page(store, account, state_function, *, page=1, page_size=25, q='', state='all', start='', end=''):
    if type(page) is not int or not 1 <= page <= 1000000 or page_size not in (25, 50, 100):
        raise ValueError('頁碼或每頁筆數不正確')
    if not isinstance(q, str) or len(q) > 200:
        raise ValueError('搜尋最多 200 字')
    if state not in ('all', 'valid', 'active', 'placed', 'draft', 'allocated', 'picked', 'staged', 'partially_shipped', 'shipped', 'cancelled'):
        raise ValueError('未知出貨狀態')
    for value in (start, end):
        if value:
            date.fromisoformat(value)
    if start and end and start > end:
        raise ValueError('起日不可晚於迄日')
    source = '''WITH linked AS (
        SELECT g.account_id,g.order_id,json_group_array(json_object(
            'id',s.id,'number',s.number,'state',s.state,'reopen_count',s.reopen_count,
            'lines',json(s.lines))) shipments
        FROM fulfillment_groups g JOIN shipments s ON s.group_id=g.id
        WHERE g.account_id=? GROUP BY g.account_id,g.order_id
    ), base AS MATERIALIZED (
        SELECT c.rowid sequence,c.order_id,v.normalized,coalesce(d.details,'{}') details,
            coalesce(l.shipments,'[]') shipments,
            portfolio_state(v.normalized,coalesce(l.shipments,'[]')) state,
            date(json_extract(v.normalized,'$.ordered_at'),'+8 hours') day
        FROM current_orders c JOIN order_versions v USING(account_id,order_id,revision)
        LEFT JOIN portfolio_checkout_details d ON d.token=lower(substr(c.order_id,6))
        LEFT JOIN linked l ON l.account_id=c.account_id AND l.order_id=c.order_id
        WHERE c.account_id=?
    ) '''
    conditions, args = [], [account, account]
    if q.strip():
        conditions.append('''(instr(lower(order_id),?)>0 OR
            instr(lower(json_extract(details,'$.customer.name')),?)>0 OR EXISTS(
                SELECT 1 FROM json_each(normalized,'$.lines') line WHERE
                instr(lower(json_extract(line.value,'$.external_sku')),?)>0 OR
                instr(lower(json_extract(line.value,'$.item_name')),?)>0))''')
        args += [q.strip().lower()] * 4
    if start:
        conditions.append('day>=?'); args.append(start)
    if end:
        conditions.append('day<=?'); args.append(end)
    where = ' WHERE ' + ' AND '.join(conditions) if conditions else ''
    with store.connect() as db:
        db.execute('BEGIN')
        db.create_function('portfolio_state', 2, lambda order, shipments:
            'cancelled' if json.loads(order)['status'] == 'cancelled'
            else state_function(json.loads(order), json.loads(shipments)), deterministic=True)
        counts = dict(db.execute(source + 'SELECT state,count(*) FROM base' + where + ' GROUP BY state', args))
        if state == 'valid':
            conditions.append("state != 'cancelled'")
        elif state == 'active':
            conditions.append("state NOT IN ('shipped','cancelled')")
        elif state != 'all':
            conditions.append('state=?'); args.append(state)
        where = ' WHERE ' + ' AND '.join(conditions) if conditions else ''
        total = sum(counts.values()) if state == 'all' else (sum(n for s,n in counts.items() if s not in ('shipped','cancelled')) if state == 'active' else sum(n for s,n in counts.items() if s != 'cancelled') if state == 'valid' else counts.get(state,0))
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(page, pages)
        rows = db.execute(source + "SELECT * FROM base" + where + " ORDER BY julianday(json_extract(normalized,'$.ordered_at')) DESC,sequence DESC LIMIT ? OFFSET ?",
                          [*args, page_size, (page - 1) * page_size]).fetchall()
        returns = order_returns(db, account, [row['order_id'] for row in rows])
    orders = []
    for row in rows:
        order, details, shipments = json.loads(row['normalized']), json.loads(row['details']), json.loads(row['shipments'])
        lines = [dict(product_id=line['product_id'], name=line.get('item_name') or line.get('external_sku',''),
                      sku=line.get('external_sku',''), quantity=line['quantity'],
                      amount=f"{line['amount_cents']/100:.2f}") for line in order['lines']]
        current = next((s for s in reversed(shipments) if s['state'] != 'cancelled'), None)
        orders.append(dict(order_id=row['order_id'], account_id=account, ordered_at=order['ordered_at'],
            total=f"{sum(l['amount_cents'] for l in order['lines'])/100:.2f}", currency='TWD',
            lines=lines, state=row['state'], returns=returns[row['order_id']], customer=details.get('customer',{}), delivery=details.get('delivery',{}),
            utm={**details.get('utm',{}), 'medium':order.get('utm_medium','')}, shipping_method=details.get('shipping_method','未記錄'),
            payment=dict(method=details.get('payment_method','未記錄'),status='模擬付款完成（未收款）'),
            shipment={k:current[k] for k in ('id','number','state','reopen_count')} if current else None))
    return dict(orders=orders, total=total, page=page, pages=pages, page_size=page_size, state_counts=counts)
