"""Order-cohort dashboard, with a separately labelled current inventory snapshot."""
import json
from collections import defaultdict
from datetime import timedelta

from ops.stock import Stock
from .pickup import date_range, in_period, instant, TAIPEI, counts


def report(server, state_function, *, start='', end='', product_id=''):
    date_range(start, end)
    account = server.portfolio['account_id']
    parcels = server.pickup.parcels(start=start, end=end)
    with server.store.connect() as db:
        db.execute('BEGIN')
        orders = [(r['order_id'], json.loads(r['normalized'])) for r in db.execute('''
            SELECT c.order_id,v.normalized FROM current_orders c JOIN order_versions v
            USING(account_id,order_id,revision) WHERE c.account_id=?''', (account,))]
        shipments = defaultdict(list)
        for r in db.execute('''SELECT g.order_id,s.state,s.lines FROM shipments s
            JOIN fulfillment_groups g ON g.id=s.group_id WHERE g.account_id=?''', (account,)):
            shipments[r['order_id']].append({'state': r['state'], 'lines': json.loads(r['lines'])})
        names = {r['id']: dict(r) for r in db.execute('SELECT p.id,p.name,d.sku FROM products p LEFT JOIN product_details d ON d.product_id=p.id')}
    valid = [(oid, o) for oid, o in orders if o['status'] != 'cancelled' and in_period(o['ordered_at'], start, end)]
    all_days = [instant(o['ordered_at']).astimezone(TAIPEI).date() for _, o in orders if o.get('ordered_at')]
    trends, products, states = {}, {}, defaultdict(int)
    amount, quantity, detail = 0, 0, []
    for oid, o in valid:
        state = state_function(o, shipments[oid])
        states[state] += 1
        day = instant(o['ordered_at']).astimezone(TAIPEI).date().isoformat()
        daily = trends.setdefault(day, {'day': day, 'amount_cents': 0, 'orders': 0})
        daily['orders'] += 1
        for line in o['lines']:
            amount += line['amount_cents']; quantity += line['quantity']
            daily['amount_cents'] += line['amount_cents']
            pid = line['product_id']
            product = products.setdefault(pid, {**names.get(pid, {'id': pid, 'name': line.get('item_name', pid), 'sku': line.get('external_sku', '')}), 'quantity': 0, 'amount_cents': 0})
            product['quantity'] += line['quantity']; product['amount_cents'] += line['amount_cents']
            if product_id == pid:
                detail.append({'order_id': oid, 'ordered_at': o['ordered_at'], 'quantity': line['quantity'], 'amount_cents': line['amount_cents']})
    # Zero-fill only bounded daily windows; long histories retain all observed daily points.
    if start and end:
        from datetime import date
        first, last = date.fromisoformat(start), date.fromisoformat(end)
    elif trends:
        from datetime import date
        first, last = date.fromisoformat(min(trends)), date.fromisoformat(max(trends))
    else:
        first = last = None
    if first and (last-first).days <= 730:
        day = first
        while day <= last:
            key = day.isoformat(); trends.setdefault(key, {'day': key, 'orders': 0, 'amount_cents': 0})
            day += timedelta(days=1)
    stock = [{'id': p['id'], 'name': p['name'], 'sku': p['sku'], 'available': p['available']}
             for p in Stock(server.store).snapshot(summary=True)['products']]
    stock.sort(key=lambda p: (p['available'], p['sku']))
    return dict(start=start, end=end, clock=server.pickup.clock(),
                data_period={'start': min(all_days).isoformat() if all_days else '', 'end': max(all_days).isoformat() if all_days else ''},
                metrics={'order_count': len(valid), 'amount_cents': amount, 'quantity': quantity,
                         'shipped': states['shipped'], 'awaiting': len(valid)-states['shipped']},
                state_counts=dict(states), trend=[trends[d] for d in sorted(trends)],
                products=sorted(products.values(), key=lambda p: (-p['quantity'], p['sku'] or '')),
                product_detail=detail, pickup=counts(parcels), parcel_count=len(parcels),
                stock=stock, low_stock=sum(p['available'] < 3 for p in stock), out_of_stock=sum(p['available'] == 0 for p in stock))
